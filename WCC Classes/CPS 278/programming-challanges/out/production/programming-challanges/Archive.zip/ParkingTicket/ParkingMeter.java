package ParkingTicket;

public class ParkingMeter {

    int purchasedTime = 10;

}
