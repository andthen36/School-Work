package Carpet;

public class RoomUI {

    public static void main (String[] args){
        RoomDimension roomDimension = new RoomDimension();
        RoomCarpet roomCarpet = new RoomCarpet();

        roomCarpet.roomCarpet();
    }
}
