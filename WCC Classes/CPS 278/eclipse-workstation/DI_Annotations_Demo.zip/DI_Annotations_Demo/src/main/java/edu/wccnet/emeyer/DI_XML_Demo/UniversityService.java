package edu.wccnet.emeyer.DI_XML_Demo;

public class UniversityService implements CollegeService {

	public String getService(String collegeName) {
		// TODO Auto-generated method stub
		return collegeName + " is a 2 year community college.";
	}

}
