package edu.wccnet.emeyer.DI_XML_Demo;

public interface FinaidService {
	String getFinaidType();

}
