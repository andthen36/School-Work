package edu.wcc.emeyer.cps278_mp2_xml;

public interface FightingPower {
	public String getFightingPowerDesc();

}
