package edu.wcc.emeyer.cps278_mp2_xml;

import org.springframework.stereotype.Component;

@Component
public interface BattleGround {
	String getBattleGroundDesc();

	

}
