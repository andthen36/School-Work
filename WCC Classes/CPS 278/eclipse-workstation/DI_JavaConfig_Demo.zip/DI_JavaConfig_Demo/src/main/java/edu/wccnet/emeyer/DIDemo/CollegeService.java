package edu.wccnet.emeyer.DIDemo;

public interface CollegeService {
	String getService(String collegeName); 
		

}
