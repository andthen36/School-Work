package edu.wcc.emeyer.cps278_mp2_xml;

import org.springframework.stereotype.Component;

@Component
public class Midgar implements BattleGround {

	@Override
	public String getBattleGroundDesc() {
		// TODO Auto-generated method stub
		return "In Midgar..";
	}

}
