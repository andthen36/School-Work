package edu.wccnet.emeyer.DIDemo;

public class Scholarships implements FinaidService {

	@Override
	public String getFinaidType() {
		// TODO Auto-generated method stub
		return "Schollarships";
	}

}
