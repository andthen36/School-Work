package edu.wccnet.emeyer.DIDemo;

public interface FinaidService {
	String getFinaidType();

}
