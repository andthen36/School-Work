package edu.wccnet.emeyer.DI_XML_Demo;

public interface CollegeService {
	String getService(String collegeName); 
		

}
