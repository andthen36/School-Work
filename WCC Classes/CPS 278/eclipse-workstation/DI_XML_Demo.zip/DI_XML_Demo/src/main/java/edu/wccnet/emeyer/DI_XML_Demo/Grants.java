package edu.wccnet.emeyer.DI_XML_Demo;

public class Grants implements FinaidService {

	@Override
	public String getFinaidType() {
		// TODO Auto-generated method stub
		return "Grants";
	}

}
