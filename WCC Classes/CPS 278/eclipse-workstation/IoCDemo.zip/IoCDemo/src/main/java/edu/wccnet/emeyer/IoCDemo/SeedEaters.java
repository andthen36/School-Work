package edu.wccnet.emeyer.IoCDemo;

public class SeedEaters implements IBrid {

	public String getEatingHabit() {
		// TODO Auto-generated method stub
		return "I eat seeds";
	}

}
