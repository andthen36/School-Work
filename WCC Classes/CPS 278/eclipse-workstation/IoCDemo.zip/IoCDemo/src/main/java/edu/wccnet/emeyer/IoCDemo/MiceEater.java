package edu.wccnet.emeyer.IoCDemo;

public class MiceEater implements IBrid {

	public String getEatingHabit() {
		// TODO Auto-generated method stub
		return "I eat mice";
	}

}
