package edu.wccnet.emeyer.IoCDemo;

public class IocDemo {

	public static void main(String[] args) {
		IBrid chickadee = new SeedEaters();
		System.out.println(chickadee.getEatingHabit());
		
	}
}
