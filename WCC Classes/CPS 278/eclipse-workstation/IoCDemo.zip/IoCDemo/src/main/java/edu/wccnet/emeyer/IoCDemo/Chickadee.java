package edu.wccnet.emeyer.IoCDemo;

public class Chickadee {
	public String getEatingHabbit() {
	return "I eat seeds";
	}

}
