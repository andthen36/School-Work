package edu.wccnet.emeyer.IoCDemo;

public interface IBrid {
	String getEatingHabit();
	
}
