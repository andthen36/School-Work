package edu.wccnet.emeyer.IoCDemo;

public class Owl {
	public String getEatingHabbit() {
		return "I eat mice";
	}
}
