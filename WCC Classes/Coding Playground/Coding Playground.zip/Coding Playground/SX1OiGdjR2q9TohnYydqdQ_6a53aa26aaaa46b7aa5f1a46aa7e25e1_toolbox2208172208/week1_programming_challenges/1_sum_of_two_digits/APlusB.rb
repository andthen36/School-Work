a, b = gets.split(' ')
puts a.to_i + b.to_i