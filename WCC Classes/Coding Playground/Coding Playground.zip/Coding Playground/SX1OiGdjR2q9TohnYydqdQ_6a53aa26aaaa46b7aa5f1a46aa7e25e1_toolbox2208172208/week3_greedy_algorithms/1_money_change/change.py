def change(money):
    # write your code here

    return money


if __name__ == '__main__':
    m = int(input())
    print(change(m))
