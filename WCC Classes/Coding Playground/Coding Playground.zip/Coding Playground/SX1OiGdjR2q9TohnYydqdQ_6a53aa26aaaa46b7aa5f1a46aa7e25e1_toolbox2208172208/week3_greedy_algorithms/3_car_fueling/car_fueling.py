from sys import stdin


def min_refills(distance, tank, stops):
    # write your code here
    return -1


if __name__ == '__main__':
    d, m, _, *stops = map(int, stdin.read().split())
    print(min_refills(d, m, stops))
