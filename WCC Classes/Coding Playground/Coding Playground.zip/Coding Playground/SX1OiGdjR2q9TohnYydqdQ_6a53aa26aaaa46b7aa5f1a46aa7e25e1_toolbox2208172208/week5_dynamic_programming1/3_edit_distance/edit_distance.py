def edit_distance(first_string, second_string):
    return 0


if __name__ == "__main__":
    print(edit_distance(input(), input()))
