#!/usr/bin/env ruby
# by Andronik Ordian

def fib_last_digit(n)
  # fix me
  0
end

if __FILE__ == $0
  n = gets.to_i
  puts "#{fib_last_digit(n)}"
end